package egg3;

import battlecode.common.*;

public strictfp class SageRobot extends Robot {

    public SageRobot(RobotController rc) {
        super(rc);
    }

    @Override
    public void run() throws GameActionException {
        //TODO
    }
}

package egg;

import battlecode.common.*;

public strictfp class WatchtowerRobot extends Robot {

    public WatchtowerRobot(RobotController rc) {
        super(rc);
    }

    @Override
    public void run() throws GameActionException {
        //TODO
    }
}

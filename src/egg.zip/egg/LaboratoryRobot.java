package egg;

import battlecode.common.*;

public strictfp class LaboratoryRobot extends Robot {

    public LaboratoryRobot(RobotController rc) {
        super(rc);
    }

    @Override
    public void run() throws GameActionException {
        //TODO
    }
}

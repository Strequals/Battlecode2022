package egg;

import battlecode.common.*;

public strictfp class BuilderRobot extends Robot {

    public BuilderRobot(RobotController rc) {
        super(rc);
    }

    @Override
    public void run() throws GameActionException {
        // TODO
    }
}
